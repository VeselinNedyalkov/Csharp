﻿using Easter.Core.Contracts;
using Easter.Models.Bunnies;
using Easter.Models.Bunnies.Contracts;
using Easter.Models.Eggs;
using Easter.Models.Eggs.Contracts;
using Easter.Repositories;
using Easter.Utilities.Messages;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using Easter.Models.Dyes.Contracts;
using Easter.Models.Dyes;

namespace Easter.Core
{
    public class Controller : IController
    {
        private EggRepository eggs;
        private BunnyRepository bunnies;

        public Controller()
        {
            eggs = new EggRepository();
            bunnies = new BunnyRepository();
        }
        public string AddBunny(string bunnyType, string bunnyName)
        {
            IBunny bynny;
            if (bunnyType == "HappyBunny")
            {
                bynny = new HappyBunny(bunnyName);
            }
            else if (bunnyType == "SleepyBunny")
            {
                bynny = new SleepyBunny(bunnyName);
            }
            else
            {
                throw new InvalidOperationException(ExceptionMessages.InvalidBunnyType);
            }
            bunnies.Add(bynny);

            return String.Format(OutputMessages.BunnyAdded, bunnyType , bunnyName);
        }

        public string AddDyeToBunny(string bunnyName, int power)
        {
            IDye dye = new Dye(power);
            IBunny bunny = bunnies.Models.FirstOrDefault(x => x.Name == bunnyName); 

            if (bunny == null)
            {
                throw new InvalidOperationException(ExceptionMessages.InexistentBunny);
            }

            bunny.AddDye(dye);

            return String.Format(OutputMessages.DyeAdded,power , bunnyName);
        }

        public string AddEgg(string eggName, int energyRequired)
        {
            IEgg egg = new Egg(eggName, energyRequired);
            eggs.Add(egg);
            return String.Format(OutputMessages.EggAdded,eggName);
        }

        public string ColorEgg(string eggName)
        {
            IEgg eggForColor = eggs.Models.Single(x => x.Name == eggName);

            if (bunnies.Models.Where(x => x.Energy >= 50).Count() == 0)
            {
                throw new InvalidOperationException(ExceptionMessages.BunniesNotReady);
            }

            List<IBunny> colectionBynnies  = new List<IBunny>(bunnies.Models.Where(x => x.Energy >= 50));

            foreach (var bunnie in colectionBynnies.OrderByDescending(x => x.Energy))
            {
                while (bunnie.Energy != 0)
                {
                    IDye dye = bunnie.Dyes.FirstOrDefault();

                    if (eggForColor.IsDone()) break;

                    if (dye == null) break;

                    bunnie.Work();
                    dye.Use();
                    eggForColor.GetColored();

                    if (dye.IsFinished())
                    {
                        bunnie.Dyes.Remove(dye);
                    }

                    if (bunnie.Energy == 0)
                    {
                        bunnies.Remove(bunnie);
                    }
                }
                if (eggForColor.IsDone()) break;
            }

           

            string endMsg = eggForColor.IsDone() ? OutputMessages.EggIsDone
                : OutputMessages.EggIsNotDone;

            return String.Format(endMsg, eggName);
        }

        public string Report()
        {
            
            StringBuilder sb = new StringBuilder();
            int countColoredEggs = eggs.Models.Where(x => x.IsDone()).Count();

            sb.AppendLine($"{countColoredEggs} eggs are done!");
            sb.AppendLine("Bunnies info:");

            foreach (var bunny in bunnies.Models)
            {
                sb.AppendLine($"Name: {bunny.Name}");
                sb.AppendLine($"Energy: {bunny.Energy}");
                sb.AppendLine($"Dyes: {bunny.Dyes.Count} not finished");
            }

            return sb.ToString().Trim();
        }
    }
}
