﻿using CarRacing.Models.Maps.Contracts;
using CarRacing.Models.Racers.Contracts;
using CarRacing.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarRacing.Models.Maps
{
    public class Map : IMap
    {
        private readonly Dictionary<string, double> multiplier = new Dictionary<string, double>
        { 
            {"strict" , 1.2 },
            {"aggressive", 1.1 }
        };
        public string StartRace(IRacer racerOne, IRacer racerTwo)
        {
            if (!racerTwo.IsAvailable())
            {
                string winerOne = string.Format(OutputMessages.OneRacerIsNotAvailable,racerOne.Username,racerTwo.Username);
                return winerOne;
            }
            else if (!racerOne.IsAvailable())
            {
                string winerOne = string.Format(OutputMessages.OneRacerIsNotAvailable, racerTwo.Username, racerOne.Username);
                return winerOne;
            }
            else if(!racerOne.IsAvailable() && !racerTwo.IsAvailable())
            {
                return OutputMessages.RaceCannotBeCompleted;
            }

            racerOne.Race();
            racerTwo.Race();

            double racerOneChanceOfWining = racerOne.Car.HorsePower * racerOne.DrivingExperience
                * multiplier[racerOne.RacingBehavior];

            double racerTwoChanceOfWining = racerTwo.Car.HorsePower * racerTwo.DrivingExperience
                * multiplier[racerTwo.RacingBehavior];

            string winer = string.Empty;
            if (racerOneChanceOfWining > racerTwoChanceOfWining)
            {
                winer = racerOne.Username;
            }
            else if (racerOneChanceOfWining < racerTwoChanceOfWining)
            {
                winer = racerTwo.Username;
            }
            string resultWiner = string.Format(OutputMessages.RacerWinsRace, racerOne.Username ,racerTwo.Username, winer);
            return resultWiner;
        }
    }
}
