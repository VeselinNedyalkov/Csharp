﻿using Gym.Core.Contracts;
using Gym.Models.Equipment;
using Gym.Models.Equipment.Contracts;
using Gym.Models.Gyms;
using Gym.Models.Gyms.Contracts;
using Gym.Repositories;
using Gym.Utilities.Messages;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using Gym.Models.Athletes.Contracts;
using Gym.Models.Athletes;

namespace Gym.Core
{
    public class Controller : IController
    {
        private readonly EquipmentRepository equipment;
        private readonly List<IGym> gyms;

        public Controller()
        {
            equipment = new EquipmentRepository();
            gyms = new List<IGym>();
        }

        public IReadOnlyCollection<IGym> Gyms
                => gyms;

        public IReadOnlyCollection<EquipmentRepository> Equipment
                => (IReadOnlyCollection<EquipmentRepository>) equipment;
        public string AddAthlete(string gymName, string athleteType, string athleteName, string motivation, int numberOfMedals)
        {
            IAthlete atlet;
            if (athleteType == "Boxer")
            {
                atlet = new Boxer(athleteName, motivation, numberOfMedals);
            }
            else if(athleteType == "Weightlifter")
            {
                atlet = new Weightlifter(athleteName, motivation,numberOfMedals);
            }
            else
            {
                throw new InvalidOperationException(ExceptionMessages.InvalidAthleteType);
            }

            IGym gymForTraining = gyms.FirstOrDefault(x => x.Name == gymName);
            if (athleteType == "Boxer" && gymForTraining.GetType().Name == "BoxingGym")
            {
                gymForTraining.AddAthlete(atlet);
            }
            else if (athleteType == "Weightlifter" && gymForTraining.GetType().Name == "WeightliftingGym")
            {
                gymForTraining.AddAthlete(atlet);
            }
            else
            {
                return OutputMessages.InappropriateGym;
            }

            return $"Successfully added {athleteType} to {gymName}.";
        }

        public string AddEquipment(string equipmentType)
        {
            IEquipment eqipment;
            if (equipmentType == "BoxingGloves")
            {
                eqipment = new BoxingGloves();
            }
            else if (equipmentType == "Kettlebell")
            {
                eqipment = new Kettlebell();
            }
            else
            {
                throw new InvalidOperationException(ExceptionMessages.InvalidEquipmentType);
            }
            equipment.Add(eqipment);
            return $"Successfully added {equipmentType}.";
        }

        public string AddGym(string gymType, string gymName)
        {
            IGym gymToADD;
            if (gymType == "BoxingGym")
            {
                gymToADD = new BoxingGym(gymName);
            }
            else if (gymType == "WeightliftingGym")
            {
                gymToADD = new WeightliftingGym(gymName);
            }
            else
            {
                throw new InvalidOperationException(ExceptionMessages.InvalidGymType);
            }

            gyms.Add(gymToADD);
            return $"Successfully added {gymType}.";
        }

        public string EquipmentWeight(string gymName)
        {

            IGym gymEquipment = gyms.FirstOrDefault(x => x.Name == gymName);

            return $"The total weight of the equipment in the gym {gymName} is {gymEquipment.EquipmentWeight:F2} grams.";
        }

        public string InsertEquipment(string gymName, string equipmentType)
        {
            IEquipment eqipToInsert = equipment.FindByType(equipmentType);
            if (eqipToInsert == null)
            {
                throw new InvalidOperationException($"There isn’t equipment of type {equipmentType}.");
            }
            IGym eqipmentToGym = gyms.FirstOrDefault(x => x.Name == gymName);
            equipment.Remove(eqipToInsert);
            eqipmentToGym.AddEquipment(eqipToInsert);
            return $"Successfully added {equipmentType} to {gymName}.";
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var gym in gyms)
            {
                sb.AppendLine(gym.GymInfo());
            }

            return sb.ToString().Trim();
        }

        public string TrainAthletes(string gymName)
        {
            IGym gumType = gyms.FirstOrDefault(x => x.Name == gymName);
            foreach (var trainer in gumType.Athletes)
            {
                trainer.Exercise();
            }
            return $"Exercise athletes: {gumType.Athletes.Count}.";
        }
    }
}
