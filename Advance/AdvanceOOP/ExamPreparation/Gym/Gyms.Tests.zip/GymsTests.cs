﻿using NUnit.Framework;
using System;
using System.Xml.Linq;

namespace Gyms.Tests
{
    [TestFixture]
    public class GymsTests
    {
       
        [Test]
        [TestCase("Veso")]
        [TestCase("Dancho")]
        [TestCase("Pesho")]
        public void AthleteFullNameTest(string name)
        {
            Athlete at = new Athlete(name);

            Assert.AreEqual(name, at.FullName);
        }

        [Test]
        public void AthleteIsInjuredTestFalse()
{
            Athlete at = new Athlete("Veso");

            Assert.IsFalse(at.IsInjured);
        }

        [Test]
        public void AthleteIsInjuredTestTreu()
        {
            Athlete at = new Athlete("Veso");
            at.IsInjured = true;
            Assert.IsTrue(at.IsInjured);
        }

        [Test]
        public void GymConstructorTestWorkAsIntended()
        {
            Gym gym = new Gym("Veso", 20);
            Assert.AreEqual("Veso", gym.Name);
            Assert.AreEqual(20, gym.Capacity);
        }

        [Test]
        [TestCase("",20)]
        [TestCase(null,20)]
        public void GymNameArgumenNullExeption(string name,int size)
        {
            Assert.Throws<ArgumentNullException>(() => new Gym(name, size));
        }

        [Test]
        [TestCase("Veso", -10)]
        [TestCase("Veso", -1)]

        public void GymCapacityArgumentException(string name, int size)
        {
            Assert.Throws<ArgumentException>(() => new Gym(name, size));
        }

        [Test]
        public void GymListAtletesCount()
        {
            Gym gym = new Gym("Veso", 20);
            Assert.AreEqual(0 , gym.Count);
        }

        [Test]
        [TestCase(2)]
        [TestCase(4)]
        [TestCase(6)]
        public void AddAtleteWorkingCorrectly(int numberOfAthlete)
        {
            Gym gym = new Gym("Veso", 20);

            for (int i = 0; i < numberOfAthlete; i++)
            {
                Athlete atlet = new Athlete(new string('A', 1 + 1));
                gym.AddAthlete(atlet);
            }

            Assert.AreEqual(numberOfAthlete, gym.Count);
        }
        Gym gym;
        [SetUp]
        public void SetUp()
        {
            gym = new Gym("Veso", 5);
            for (int i = 0; i < 5; i++)
            {
                Athlete atlet = new Athlete(new string('A', 1 + 1));
                gym.AddAthlete(atlet);
            }
        }

        [Test]
        public void AddAthleteExeption()
        {
          
            Athlete atletOne = new Athlete("Veso");
            Assert.Throws<InvalidOperationException>(() => gym.AddAthlete(atletOne));
        }

        [Test]
        public void RemoveAthleteProperWork()
        {
            gym.RemoveAthlete("AA");

            Assert.AreEqual(4 , gym.Count);
        }

        [Test]
        public void RemoveAthleteExeption()
        {

            Assert.Throws<InvalidOperationException>(() => gym.RemoveAthlete("Bbb"));
        }

        [Test]
        public void AthleteIsInjuredTrue()
        {
            var injur = gym.InjureAthlete("AA");
            Assert.IsTrue(injur.IsInjured);
        }

        [Test]
        public void AthleteExeptionIfNameIsMissing()
        {
            Assert.Throws<InvalidOperationException>(() => gym.InjureAthlete("bb"));
        }

        [Test]
        [TestCase("Veso")]
        [TestCase("Dani")]
        [TestCase("Svetla")]

        public void ReportTesting(string name)
        {
            Gym gymnasium = new Gym("Exo", 5);
            gymnasium.AddAthlete(new Athlete(name));
            Assert.AreEqual($"Active athletes at Exo: {name}", gymnasium.Report());
        }
    }
}
