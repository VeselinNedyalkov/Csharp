﻿using System;

using WarCroft.Constants;
using WarCroft.Entities.Inventory;

namespace WarCroft.Entities.Characters.Contracts
{
    public abstract class Character
    {
        private string name;
        private double baseHealth;
        private double health;
        private double armor;
        private double abilityPoints;
        private IBag bags;

        protected Character(string name, double health,
            double armor, double abilityPoints, IBag bags)
        {
            Name = name;
            Health = health;
            Armor = armor;
            AbilityPoints = abilityPoints;
            baseHealth = health;
            Bags = bags;
        }

        public string Name
        {
            get => name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException(ExceptionMessages.CharacterNameInvalid);
                }
                name = value;
            }
        }
        public  double BaseHealth { get => baseHealth; private set => baseHealth = value; }
        public double Health
        {
            get => health;
            internal set
            {
                if (health + value > BaseHealth)
                {
                    health = BaseHealth;
                }
                else if (health - value < 0)
                {
                    health = 0;
                    IsAlive = false;
                }
                else
                {
                    health = value;
                }

            }
        }

        public double Armor
        {
            get => armor;
            private set
            {
                if (armor - value < 0)
                {
                    armor = 0;
                }
                else
                {
                    armor = value;
                }

            }
        }

        public double AbilityPoints { get => abilityPoints; private set => abilityPoints = value; }
        public IBag Bags { get => bags; private set => bags = value; }
        public bool IsAlive { get; set; } = true;

        protected void EnsureAlive()
        {
            if (!this.IsAlive)
            {
                throw new InvalidOperationException(ExceptionMessages.AffectedCharacterDead);
            }
        }

        public void TakeDamage(double hitPoints)
        {
            double damage = 0;
            if (this.Armor - hitPoints >= 0)
            {
                this.Armor -= hitPoints;
            }
            else
            {
                damage = this.Armor - hitPoints;
                this.Health -= damage;
            }
        }
    }

}