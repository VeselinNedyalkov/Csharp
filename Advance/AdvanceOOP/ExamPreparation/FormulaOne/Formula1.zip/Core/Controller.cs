﻿using Formula1.Core.Contracts;
using Formula1.Models.Contracts;
using Formula1.Repositories;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using Formula1.Utilities;
using Formula1.Models;

namespace Formula1.Core
{
    public class Controller : IController
    {
        private PilotRepository pilots;
        private RaceRepository races;
        private FormulaOneCarRepository formulOne;

        public Controller()
        {
            pilots = new PilotRepository();
            races = new RaceRepository();
            formulOne = new FormulaOneCarRepository();
        }


        public string AddCarToPilot(string pilotName, string carModel)
        {
            IPilot pilot = pilots.FindByName(pilotName);
            if (pilot == null || pilot.Car != null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.PilotDoesNotExistOrHasCarErrorMessage,pilotName));
            }

            IFormulaOneCar car = formulOne.FindByName(carModel);
            if (car == null)
            {
                throw new NullReferenceException(string.Format(ExceptionMessages.CarDoesNotExistErrorMessage, carModel));
            }

            pilot.AddCar(car);
            return string.Format(OutputMessages.SuccessfullyPilotToCar,pilotName, car.GetType().Name , carModel);
        }

        public string AddPilotToRace(string raceName, string pilotFullName)
        {
            IRace race = races.FindByName(raceName);
            if (race == null)
            {
                throw new NullReferenceException(string.Format(ExceptionMessages.RaceDoesNotExistErrorMessage,raceName));
            }

            IPilot pilot = pilots.FindByName(pilotFullName);
            if (pilot == null || !pilot.CanRace || race.Pilots.Any(x => x.FullName == pilotFullName))
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.PilotDoesNotExistErrorMessage, pilotFullName));
            }
            race.AddPilot(pilot);
            return string.Format(OutputMessages.SuccessfullyAddPilotToRace,pilotFullName, raceName);
        }

        public string CreateCar(string type, string model, int horsepower, double engineDisplacement)
        {
            IFormulaOneCar car = formulOne.FindByName(model);
            if (car != null)
            {
               throw new InvalidOperationException(string.Format(ExceptionMessages.CarExistErrorMessage, model));
            }

            switch (type)
            {
                case "Ferrari":
                    car = new Ferrari(model, horsepower, engineDisplacement);
                    break;
                case "Williams":
                    car = new Williams(model, horsepower, engineDisplacement);  
                    break;
                default:
                    throw new InvalidOperationException(string.Format(ExceptionMessages.InvalidTypeCar,type));   
            }

            formulOne.Add(car);

            return string.Format(OutputMessages.SuccessfullyCreateCar,type,model);
        }

        public string CreatePilot(string fullName)
        {
            IPilot pilot = pilots.FindByName(fullName);
            if (pilot != null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.PilotExistErrorMessage, fullName));
            }

            pilot = new Pilot(fullName);
            pilots.Add(pilot);

            return string.Format(OutputMessages.SuccessfullyCreatePilot, fullName);
        }

        public string CreateRace(string raceName, int numberOfLaps)
        {
            IRace race = races.FindByName(raceName);
            if (race != null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.RaceExistErrorMessage,raceName));
            }

            race = new Race(raceName, numberOfLaps);
            races.Add(race);

            return string.Format(OutputMessages.SuccessfullyCreateRace, raceName);
        }

        public string PilotReport()
        {
            StringBuilder sb = new StringBuilder();

            foreach (var pilot in pilots.Models.OrderByDescending(x => x.NumberOfWins))
            {
                sb.AppendLine(pilot.ToString());
            }

            return sb.ToString().Trim();
        }

        public string RaceReport()
        {
            StringBuilder sb = new StringBuilder();

            foreach (var race in races.Models.Where(x => x.TookPlace == true))
            {
                sb.AppendLine(race.RaceInfo());
            }

            return sb.ToString().Trim();
        }

        public string StartRace(string raceName)
        {
            IRace race = races.FindByName(raceName);
            if (race == null)
            {
                throw new NullReferenceException(String.Format(ExceptionMessages.RaceDoesNotExistErrorMessage, raceName));
            }

            if (race.Pilots.Count < 3)
            {
                throw new NullReferenceException(String.Format(ExceptionMessages.InvalidRaceParticipants, raceName));
            }

            if (race.TookPlace)
            {
                throw new NullReferenceException(String.Format(ExceptionMessages.RaceTookPlaceErrorMessage, raceName));

            }
            StringBuilder sb = new StringBuilder();

            race.TookPlace = true;
            IPilot[] pilotWiners = new IPilot[3];
            int i = 0;
            foreach (var pilot in race.Pilots.OrderByDescending(x => x.Car.RaceScoreCalculator(race.NumberOfLaps)))
            {
                if(i == 3)
                {
                    break;
                }
                pilotWiners[i] = pilot;
                i++;
            }
            pilotWiners[0].WinRace();

            sb.AppendLine(String.Format(OutputMessages.PilotFirstPlace, pilotWiners[0].FullName , race.RaceName));
            sb.AppendLine(String.Format(OutputMessages.PilotSecondPlace, pilotWiners[1].FullName, race.RaceName));
            sb.AppendLine(String.Format(OutputMessages.PilotThirdPlace, pilotWiners[2].FullName, race.RaceName));

            return sb.ToString().Trim();
        }
    }
}
